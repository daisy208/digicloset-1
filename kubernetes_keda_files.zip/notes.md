Notes & How to wire this to your Digicloset setup
------------------------------------------------
1. This ScaledObject assumes you have a Redis service in the same namespace named `redis`
   (hostname: redis.default.svc.cluster.local:6379). Adjust `address` if different.

2. The scaler watches a Redis LIST named `tryon_queue`. Your producer (Node API)
   should push job IDs or payload references to this list when a try-on request is created:

       LPUSH tryon_queue "<job_id>"

   The AI worker (Celery/RQ) should pop items from the same list (RPOP/LPOP) to process jobs.

3. Set Redis password in Kubernetes secret `tryon-secrets` with key `REDIS_PASSWORD`:

       kubectl create secret generic tryon-secrets \
         --from-literal=DATABASE_URL="your_database_url" \
         --from-literal=SUPABASE_KEY="your_supabase_key" \
         --from-literal=AI_SERVICE_URL="http://tryon-ai-worker:5000" \
         --from-literal=REDIS_PASSWORD="your_redis_password" \
         -n <your-namespace>

4. Min replicas is set to 0 (cold scale). If you want always-on workers, set minReplicaCount >= 1.
5. Tune `listLength` and `maxReplicaCount` based on benchmarked throughput per worker.
6. After installing KEDA, apply these files:

       kubectl apply -f keda-trigger-auth.yaml
       kubectl apply -f keda-scaledobject.yaml

7. Use `kubectl get scaledobjects` and `kubectl describe scaledobject tryon-ai-scaledobject` to inspect.
